# BasedDoor test suite
